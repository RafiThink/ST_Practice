

void UART2_Init(unsigned int);
void printchar(unsigned int Char);
void SerialPrint(char data[]);
void newline(void);

//APB1 Bit-17 : UART2 Clock Bus (Maximum 50MHz)
