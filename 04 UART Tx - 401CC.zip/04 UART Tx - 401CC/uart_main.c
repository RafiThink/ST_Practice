//The Start Bit is always zero (always single bit)
//The stop bit is always 1 (Either single or double bit)

#include "stm32f4xx.h"                  // Device header
#include"stm32f401xx_UART.h"
#include "stm32f401xx_delay.h"

int main(void)
{
	UART2_Init(1200);
	while(1)
	{ 
		SerialPrint("Hello World ");
	  newline();
		_delay_ms(1000);
	}
}





