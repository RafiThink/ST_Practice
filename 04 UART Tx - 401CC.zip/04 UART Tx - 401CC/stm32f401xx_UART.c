#include"stm32f401xx_UART.h"
#include "stm32f4xx.h"
#include "stm32f401xx_delay.h"
#include<string.h>

void UART2_Init(unsigned int Baud_Rate)
{
	RCC->APB1ENR |= (1<<17);
	
	//Alternate Funtion 7 is USART2 (Section 8.3.2 figure 17)
	//Activate Alternate Functions for GPIO and AHB bus for PORTA
	//PA2 : USART2 Tx & PA3 : USART2 Rx 
	RCC->AHB1ENR |=(1<<0);
	GPIOA->MODER |= 0xA0;
	GPIOA->AFR[0] |= 0x0700; //Alternate Function 7 is set for PA2

	USART2->BRR |= 16000000/Baud_Rate;  //9600 at 8MHz
	USART2->CR1 |= (1<<3);  //Transmission Enabled
	USART2->CR1 |= (1<<13); //USART Enabled 
	_delay_ms(100);
}

void printchar(unsigned int Char)
{
	while(!(USART2->SR & 0x0080)){}
	USART2->DR = Char;
}

void SerialPrint(char *data)
{
	unsigned int temp;
	for(temp=0;temp<=strlen(data)-1;temp++)
	{
		printchar(data[temp]);
		_delay_ms(10);
	}
}

void newline(void)
{
	printchar(10);
}
