#define F_CPU 16000000

void _delay_ms(volatile int expected_delay);
