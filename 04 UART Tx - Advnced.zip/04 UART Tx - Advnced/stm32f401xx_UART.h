
//PA2 : USART2 Tx & PA3 : USART2 Rx
void UART2_Init(unsigned int Baud_Rate);      //To enable UART2
void printchar2(unsigned int Char);           //To print a character
void SerialPrint2(char data[]);               //To print a line
void newline2(void);                          //To print a new line
//N.B. You may add "\r\n" instaed of newline

//PA9 : USART1 TX & PA10 USART1 RX
void UART1_Init(unsigned int Baud_Rate);
void printchar1(unsigned int Char);
void SerialPrint1(char data[]);
void newline1(void);

//APB1 Bit-17 : UART2 Clock Bus (Maximum 50MHz)
